// app/(tabs)/health.tsx — Health Dashboard: water, sleep, steps, exercise, weight
import React from "react";
import { View, Text, Pressable, StyleSheet, useColorScheme } from "react-native";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "../../src/lib/supabase";
import { lightTheme, darkTheme, spacing, radius } from "../../src/lib/theme";

const WATER_GOAL_ML = 2000;
const WATER_INCREMENT = 250;
const STEPS_GOAL = 8000;

async function logHealth(logType: string, value: number, unit: string) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return;
  await supabase.from("health_logs").insert({
    user_id: user.id,
    log_type: logType,
    value,
    unit,
    source: "manual",
  });
}

function todayRange() {
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  return start.toISOString();
}

export default function HealthScreen() {
  const scheme = useColorScheme();
  const theme = scheme === "dark" ? darkTheme : lightTheme;
  const queryClient = useQueryClient();

  const { data: todayLogs } = useQuery({
    queryKey: ["health-today"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("health_logs")
        .select("log_type, value")
        .gte("logged_at", todayRange());
      if (error) throw error;
      return data ?? [];
    },
  });

  const waterMl = (todayLogs ?? [])
    .filter((l) => l.log_type === "water")
    .reduce((a, l) => a + Number(l.value), 0);
  const steps = (todayLogs ?? [])
    .filter((l) => l.log_type === "steps")
    .reduce((a, l) => a + Number(l.value), 0);
  const exerciseMin = (todayLogs ?? [])
    .filter((l) => l.log_type === "exercise")
    .reduce((a, l) => a + Number(l.value), 0);
  const sleepHrs = (todayLogs ?? [])
    .filter((l) => l.log_type === "sleep")
    .reduce((a, l) => a + Number(l.value), 0);

  function refresh() {
    queryClient.invalidateQueries({ queryKey: ["health-today"] });
  }

  const trackers = [
    {
      key: "water",
      title: "Water",
      value: `${waterMl} / ${WATER_GOAL_ML} ml`,
      progress: Math.min(1, waterMl / WATER_GOAL_ML),
      action: () => logHealth("water", WATER_INCREMENT, "ml").then(refresh),
      actionLabel: `+${WATER_INCREMENT}ml`,
    },
    {
      key: "steps",
      title: "Steps",
      value: `${steps.toLocaleString()} / ${STEPS_GOAL.toLocaleString()}`,
      progress: Math.min(1, steps / STEPS_GOAL),
      action: () => logHealth("steps", 1000, "steps").then(refresh),
      actionLabel: "+1,000 (manual)",
    },
    {
      key: "exercise",
      title: "Exercise",
      value: `${exerciseMin} min today`,
      progress: Math.min(1, exerciseMin / 30),
      action: () => logHealth("exercise", 15, "minutes").then(refresh),
      actionLabel: "+15 min",
    },
    {
      key: "sleep",
      title: "Sleep (last check-in)",
      value: `${sleepHrs || "—"} hrs`,
      progress: Math.min(1, sleepHrs / 8),
      action: null,
      actionLabel: null,
    },
  ];

  return (
    <View style={[styles.container, { backgroundColor: theme.bg }]}>
      <Text style={[styles.header, { color: theme.text }]}>Health</Text>
      {trackers.map((t) => (
        <View key={t.key} style={[styles.card, { backgroundColor: theme.surface, borderColor: theme.border }]}>
          <View style={styles.cardHeaderRow}>
            <Text style={[styles.cardTitle, { color: theme.text }]}>{t.title}</Text>
            <Text style={[styles.cardValue, { color: theme.textMuted }]}>{t.value}</Text>
          </View>
          <View style={[styles.progressTrack, { backgroundColor: theme.border }]}>
            <View
              style={[
                styles.progressFill,
                { width: `${t.progress * 100}%`, backgroundColor: theme.primary },
              ]}
            />
          </View>
          {t.action && (
            <Pressable onPress={t.action} style={[styles.logButton, { borderColor: theme.border }]}>
              <Text style={[styles.logButtonText, { color: theme.primary }]}>{t.actionLabel}</Text>
            </Pressable>
          )}
        </View>
      ))}
      <Text style={[styles.wearableNote, { color: theme.textMuted }]}>
        Connect Apple Health / Google Health Connect for automatic step & heart rate sync — Premium feature.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: spacing.lg, paddingTop: spacing.xl * 1.5, gap: spacing.md },
  header: { fontSize: 24, fontWeight: "700", marginBottom: spacing.sm },
  card: { borderWidth: 1, borderRadius: radius.lg, padding: spacing.md, gap: spacing.sm },
  cardHeaderRow: { flexDirection: "row", justifyContent: "space-between" },
  cardTitle: { fontSize: 15, fontWeight: "600" },
  cardValue: { fontSize: 13 },
  progressTrack: { height: 8, borderRadius: radius.full, overflow: "hidden" },
  progressFill: { height: 8, borderRadius: radius.full },
  logButton: { alignSelf: "flex-start", borderWidth: 1, borderRadius: radius.full, paddingVertical: 6, paddingHorizontal: spacing.md },
  logButtonText: { fontWeight: "600", fontSize: 13 },
  wearableNote: { fontSize: 12, textAlign: "center", marginTop: spacing.sm },
});

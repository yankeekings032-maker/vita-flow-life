// app/(tabs)/index.tsx — "Today" screen: the heart of the core loop
import React from "react";
import { View, Text, ScrollView, Pressable, StyleSheet, useColorScheme } from "react-native";
import { useRouter } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { supabase, getLatestScore, getLatestInsight } from "../../src/lib/supabase";
import { ScoreRing } from "../../src/components/ui/ScoreRing";
import { lightTheme, darkTheme, spacing, radius } from "../../src/lib/theme";

export default function TodayScreen() {
  const router = useRouter();
  const scheme = useColorScheme();
  const theme = scheme === "dark" ? darkTheme : lightTheme;

  const { data: userId } = useQuery({
    queryKey: ["current-user"],
    queryFn: async () => {
      const { data } = await supabase.auth.getUser();
      return data.user?.id ?? null;
    },
  });

  const { data: score } = useQuery({
    queryKey: ["latest-score", userId],
    queryFn: () => getLatestScore(userId as string),
    enabled: !!userId,
  });

  const { data: insight } = useQuery({
    queryKey: ["latest-insight", userId],
    queryFn: () => getLatestInsight(userId as string),
    enabled: !!userId,
  });

  const hasCheckedInToday = !!score && score.score_date === new Date().toISOString().slice(0, 10);

  return (
    <ScrollView
      style={{ backgroundColor: theme.bg }}
      contentContainerStyle={styles.container}
    >
      <Text style={[styles.greeting, { color: theme.text }]}>Good morning 👋</Text>

      <View style={styles.ringWrap}>
        <ScoreRing score={score?.overall_score ?? null} />
      </View>

      {insight && (
        <View style={[styles.insightCard, { backgroundColor: theme.surface, borderColor: theme.border }]}>
          <Text style={[styles.insightLabel, { color: theme.primary }]}>AI INSIGHT</Text>
          <Text style={[styles.insightText, { color: theme.text }]}>{insight.insight_text}</Text>
          {insight.recommendation_text && (
            <Text style={[styles.insightRec, { color: theme.textMuted }]}>
              {insight.recommendation_text}
            </Text>
          )}
        </View>
      )}

      <Pressable
        onPress={() => router.push("/checkin/mood")}
        style={[
          styles.ctaButton,
          { backgroundColor: hasCheckedInToday ? theme.surface : theme.primary, borderColor: theme.border },
        ]}
      >
        <Text style={[styles.ctaText, { color: hasCheckedInToday ? theme.text : "#fff" }]}>
          {hasCheckedInToday ? "Update today's check-in" : "Start today's check-in (60s)"}
        </Text>
      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: spacing.lg, paddingTop: spacing.xl * 1.5, gap: spacing.lg },
  greeting: { fontSize: 24, fontWeight: "700" },
  ringWrap: { alignItems: "center", marginVertical: spacing.md },
  insightCard: { borderWidth: 1, borderRadius: radius.lg, padding: spacing.md, gap: spacing.xs },
  insightLabel: { fontSize: 11, fontWeight: "700", letterSpacing: 0.5 },
  insightText: { fontSize: 16, fontWeight: "600" },
  insightRec: { fontSize: 14 },
  ctaButton: { borderWidth: 1, borderRadius: radius.full, paddingVertical: 16, alignItems: "center" },
  ctaText: { fontSize: 16, fontWeight: "600" },
});

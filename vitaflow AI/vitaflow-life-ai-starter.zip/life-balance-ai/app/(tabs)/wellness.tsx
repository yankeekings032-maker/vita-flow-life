// app/(tabs)/wellness.tsx — Mental Wellness: gratitude journal, breathing, mood calendar
import React, { useState, useEffect, useRef } from "react";
import { View, Text, TextInput, Pressable, ScrollView, StyleSheet, useColorScheme, Animated } from "react-native";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "../../src/lib/supabase";
import { lightTheme, darkTheme, spacing, radius } from "../../src/lib/theme";

const BREATH_PATTERN = { inhale: 4, hold: 4, exhale: 4, holdEmpty: 4 }; // box breathing

export default function WellnessScreen() {
  const scheme = useColorScheme();
  const theme = scheme === "dark" ? darkTheme : lightTheme;
  const queryClient = useQueryClient();
  const [gratitudeText, setGratitudeText] = useState("");
  const [breathingActive, setBreathingActive] = useState(false);
  const scale = useRef(new Animated.Value(1)).current;

  const { data: entries } = useQuery({
    queryKey: ["journal-entries"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("journal_entries")
        .select("id, content, entry_type, created_at")
        .order("created_at", { ascending: false })
        .limit(10);
      if (error) throw error;
      return data ?? [];
    },
  });

  async function saveGratitude() {
    if (!gratitudeText.trim()) return;
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;
    await supabase.from("journal_entries").insert({
      user_id: user.id,
      entry_type: "gratitude",
      content: gratitudeText.trim(),
    });
    setGratitudeText("");
    queryClient.invalidateQueries({ queryKey: ["journal-entries"] });
  }

  useEffect(() => {
    if (!breathingActive) {
      scale.setValue(1);
      return;
    }
    const cycle = Animated.loop(
      Animated.sequence([
        Animated.timing(scale, {
          toValue: 1.6,
          duration: BREATH_PATTERN.inhale * 1000,
          useNativeDriver: true,
        }),
        Animated.delay(BREATH_PATTERN.hold * 1000),
        Animated.timing(scale, {
          toValue: 1,
          duration: BREATH_PATTERN.exhale * 1000,
          useNativeDriver: true,
        }),
        Animated.delay(BREATH_PATTERN.holdEmpty * 1000),
      ])
    );
    cycle.start();
    return () => cycle.stop();
  }, [breathingActive]);

  async function endBreathingSession(durationSeconds: number) {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;
    await supabase.from("breathing_sessions").insert({
      user_id: user.id,
      pattern: "box",
      duration_seconds: durationSeconds,
    });
  }

  return (
    <ScrollView style={{ backgroundColor: theme.bg }} contentContainerStyle={styles.container}>
      <Text style={[styles.header, { color: theme.text }]}>Mental Wellness</Text>

      {/* Guided breathing */}
      <View style={[styles.card, { backgroundColor: theme.surface, borderColor: theme.border }]}>
        <Text style={[styles.cardTitle, { color: theme.text }]}>Guided breathing</Text>
        <View style={styles.breathWrap}>
          <Animated.View
            style={[
              styles.breathCircle,
              { backgroundColor: theme.primary, transform: [{ scale }] },
            ]}
          />
        </View>
        <Pressable
          onPress={() => {
            const next = !breathingActive;
            setBreathingActive(next);
            if (!next) endBreathingSession(60);
          }}
          style={[styles.pillButton, { backgroundColor: theme.primary }]}
        >
          <Text style={styles.pillButtonText}>{breathingActive ? "Stop" : "Start box breathing"}</Text>
        </Pressable>
      </View>

      {/* Gratitude journal */}
      <View style={[styles.card, { backgroundColor: theme.surface, borderColor: theme.border }]}>
        <Text style={[styles.cardTitle, { color: theme.text }]}>Today I'm grateful for...</Text>
        <TextInput
          value={gratitudeText}
          onChangeText={setGratitudeText}
          placeholder="One small thing that went well today"
          placeholderTextColor={theme.textMuted}
          multiline
          style={[styles.textArea, { color: theme.text, borderColor: theme.border }]}
        />
        <Pressable onPress={saveGratitude} style={[styles.pillButton, { backgroundColor: theme.primary }]}>
          <Text style={styles.pillButtonText}>Save entry</Text>
        </Pressable>
      </View>

      {/* Recent entries */}
      <Text style={[styles.subheader, { color: theme.text }]}>Recent reflections</Text>
      {(entries ?? []).map((e) => (
        <View key={e.id} style={[styles.entryRow, { borderColor: theme.border }]}>
          <Text style={[styles.entryText, { color: theme.text }]}>{e.content}</Text>
          <Text style={[styles.entryDate, { color: theme.textMuted }]}>
            {new Date(e.created_at).toLocaleDateString()}
          </Text>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: spacing.lg, paddingTop: spacing.xl * 1.5, gap: spacing.md },
  header: { fontSize: 24, fontWeight: "700" },
  subheader: { fontSize: 16, fontWeight: "600", marginTop: spacing.sm },
  card: { borderWidth: 1, borderRadius: radius.lg, padding: spacing.md, gap: spacing.md, alignItems: "center" },
  cardTitle: { fontSize: 15, fontWeight: "600", alignSelf: "flex-start" },
  breathWrap: { height: 140, alignItems: "center", justifyContent: "center" },
  breathCircle: { width: 60, height: 60, borderRadius: radius.full, opacity: 0.85 },
  pillButton: { borderRadius: radius.full, paddingVertical: 12, paddingHorizontal: spacing.lg, alignSelf: "stretch", alignItems: "center" },
  pillButtonText: { color: "#fff", fontWeight: "600" },
  textArea: { borderWidth: 1, borderRadius: radius.md, padding: spacing.md, minHeight: 70, alignSelf: "stretch", textAlignVertical: "top" },
  entryRow: { borderBottomWidth: 1, paddingBottom: spacing.sm, gap: 2 },
  entryText: { fontSize: 14 },
  entryDate: { fontSize: 11 },
});

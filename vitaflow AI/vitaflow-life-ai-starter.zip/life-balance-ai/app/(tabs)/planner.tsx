// app/(tabs)/planner.tsx — Smart Daily Planner: priorities, tasks, Pomodoro
import React, { useState, useEffect, useRef } from "react";
import { View, Text, FlatList, Pressable, TextInput, StyleSheet, useColorScheme } from "react-native";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "../../src/lib/supabase";
import { lightTheme, darkTheme, spacing, radius } from "../../src/lib/theme";

const POMODORO_SECONDS = 25 * 60;

interface Task {
  id: string;
  title: string;
  status: "pending" | "in_progress" | "done" | "skipped";
  is_deep_work: boolean;
  priority: number;
}

export default function PlannerScreen() {
  const scheme = useColorScheme();
  const theme = scheme === "dark" ? darkTheme : lightTheme;
  const queryClient = useQueryClient();
  const [newTaskTitle, setNewTaskTitle] = useState("");

  const [secondsLeft, setSecondsLeft] = useState(POMODORO_SECONDS);
  const [timerRunning, setTimerRunning] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const { data: tasks } = useQuery<Task[]>({
    queryKey: ["tasks", "today"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("tasks")
        .select("id, title, status, is_deep_work, priority")
        .eq("due_date", new Date().toISOString().slice(0, 10))
        .order("priority", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  });

  useEffect(() => {
    if (timerRunning) {
      intervalRef.current = setInterval(() => {
        setSecondsLeft((s) => {
          if (s <= 1) {
            setTimerRunning(false);
            if (intervalRef.current) clearInterval(intervalRef.current);
            return 0;
          }
          return s - 1;
        });
      }, 1000);
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [timerRunning]);

  async function addTask() {
    if (!newTaskTitle.trim()) return;
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    await supabase.from("tasks").insert({
      user_id: user.id,
      title: newTaskTitle.trim(),
      due_date: new Date().toISOString().slice(0, 10),
      priority: 2,
    });
    setNewTaskTitle("");
    queryClient.invalidateQueries({ queryKey: ["tasks", "today"] });
  }

  async function toggleDone(task: Task) {
    await supabase
      .from("tasks")
      .update({ status: task.status === "done" ? "pending" : "done" })
      .eq("id", task.id);
    queryClient.invalidateQueries({ queryKey: ["tasks", "today"] });
  }

  const minutes = String(Math.floor(secondsLeft / 60)).padStart(2, "0");
  const seconds = String(secondsLeft % 60).padStart(2, "0");

  return (
    <View style={[styles.container, { backgroundColor: theme.bg }]}>
      <Text style={[styles.header, { color: theme.text }]}>Today's Plan</Text>

      {/* Pomodoro */}
      <View style={[styles.pomodoroCard, { backgroundColor: theme.surface, borderColor: theme.border }]}>
        <Text style={[styles.timerText, { color: theme.text }]}>
          {minutes}:{seconds}
        </Text>
        <View style={styles.timerButtonsRow}>
          <Pressable
            onPress={() => setTimerRunning((r) => !r)}
            style={[styles.timerButton, { backgroundColor: theme.primary }]}
          >
            <Text style={styles.timerButtonText}>{timerRunning ? "Pause" : "Start focus block"}</Text>
          </Pressable>
          <Pressable
            onPress={() => {
              setTimerRunning(false);
              setSecondsLeft(POMODORO_SECONDS);
            }}
            style={[styles.timerButton, { backgroundColor: theme.bg, borderWidth: 1, borderColor: theme.border }]}
          >
            <Text style={[styles.timerButtonText, { color: theme.text }]}>Reset</Text>
          </Pressable>
        </View>
      </View>

      {/* Add task */}
      <View style={styles.addRow}>
        <TextInput
          value={newTaskTitle}
          onChangeText={setNewTaskTitle}
          onSubmitEditing={addTask}
          placeholder="Add a priority for today"
          placeholderTextColor={theme.textMuted}
          style={[styles.input, { color: theme.text, borderColor: theme.border }]}
        />
        <Pressable onPress={addTask} style={[styles.addButton, { backgroundColor: theme.primary }]}>
          <Text style={styles.addButtonText}>+</Text>
        </Pressable>
      </View>

      <FlatList
        data={tasks ?? []}
        keyExtractor={(t) => t.id}
        contentContainerStyle={{ gap: spacing.sm }}
        renderItem={({ item }) => (
          <Pressable
            onPress={() => toggleDone(item)}
            style={[styles.taskRow, { backgroundColor: theme.surface, borderColor: theme.border }]}
          >
            <View
              style={[
                styles.checkbox,
                {
                  backgroundColor: item.status === "done" ? theme.success : "transparent",
                  borderColor: item.status === "done" ? theme.success : theme.border,
                },
              ]}
            />
            <Text
              style={[
                styles.taskText,
                {
                  color: theme.text,
                  textDecorationLine: item.status === "done" ? "line-through" : "none",
                },
              ]}
            >
              {item.title}
            </Text>
            {item.is_deep_work && <Text style={styles.deepWorkTag}>🧠</Text>}
          </Pressable>
        )}
        ListEmptyComponent={
          <Text style={{ color: theme.textMuted, textAlign: "center", marginTop: spacing.lg }}>
            No priorities set for today yet.
          </Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: spacing.lg, paddingTop: spacing.xl * 1.5, gap: spacing.md },
  header: { fontSize: 24, fontWeight: "700" },
  pomodoroCard: { borderWidth: 1, borderRadius: radius.lg, padding: spacing.lg, alignItems: "center", gap: spacing.md },
  timerText: { fontSize: 48, fontWeight: "700", fontVariant: ["tabular-nums"] },
  timerButtonsRow: { flexDirection: "row", gap: spacing.sm },
  timerButton: { paddingVertical: 10, paddingHorizontal: spacing.md, borderRadius: radius.full },
  timerButtonText: { color: "#fff", fontWeight: "600" },
  addRow: { flexDirection: "row", gap: spacing.sm },
  input: { flex: 1, borderWidth: 1, borderRadius: radius.md, padding: spacing.md },
  addButton: { width: 48, height: 48, borderRadius: radius.md, alignItems: "center", justifyContent: "center" },
  addButtonText: { color: "#fff", fontSize: 22, fontWeight: "700" },
  taskRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm, padding: spacing.md, borderWidth: 1, borderRadius: radius.md },
  checkbox: { width: 22, height: 22, borderRadius: radius.sm, borderWidth: 2 },
  taskText: { flex: 1, fontSize: 15 },
  deepWorkTag: { fontSize: 14 },
});

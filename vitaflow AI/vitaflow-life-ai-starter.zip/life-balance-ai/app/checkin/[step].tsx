// app/checkin/[step].tsx — 60-second daily check-in (mood -> energy -> sleep -> priorities)
import React, { useState } from "react";
import { View, Text, Pressable, TextInput, StyleSheet, useColorScheme } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { submitCheckin } from "../../src/lib/supabase";
import { lightTheme, darkTheme, spacing, radius } from "../../src/lib/theme";

const STEPS = ["mood", "energy", "sleep", "priorities"] as const;
type Step = (typeof STEPS)[number];

// Local draft state persists across steps via router params would be clunky —
// in production this lives in a Zustand store (useCheckinDraft). Simplified here.
let draft = { mood: 3, energy: 3, sleep_hours: 7, top_priorities: [] as string[] };

export default function CheckinStepScreen() {
  const { step } = useLocalSearchParams<{ step: Step }>();
  const router = useRouter();
  const scheme = useColorScheme();
  const theme = scheme === "dark" ? darkTheme : lightTheme;
  const [priorityInput, setPriorityInput] = useState("");

  const currentIndex = STEPS.indexOf(step as Step);

  async function goNext() {
    if (currentIndex < STEPS.length - 1) {
      router.push(`/checkin/${STEPS[currentIndex + 1]}`);
    } else {
      await submitCheckin(draft);
      draft = { mood: 3, energy: 3, sleep_hours: 7, top_priorities: [] };
      router.replace("/(tabs)");
    }
  }

  function ScaleSelector({ value, onChange }: { value: number; onChange: (v: number) => void }) {
    return (
      <View style={styles.scaleRow}>
        {[1, 2, 3, 4, 5].map((n) => (
          <Pressable
            key={n}
            onPress={() => onChange(n)}
            style={[
              styles.scaleDot,
              {
                backgroundColor: value === n ? theme.primary : theme.surface,
                borderColor: theme.border,
              },
            ]}
          >
            <Text style={{ color: value === n ? "#fff" : theme.text, fontWeight: "600" }}>{n}</Text>
          </Pressable>
        ))}
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.bg }]}>
      <View style={styles.progressRow}>
        {STEPS.map((s, i) => (
          <View
            key={s}
            style={[
              styles.progressDot,
              { backgroundColor: i <= currentIndex ? theme.primary : theme.border },
            ]}
          />
        ))}
      </View>

      {step === "mood" && (
        <>
          <Text style={[styles.question, { color: theme.text }]}>How's your mood right now?</Text>
          <ScaleSelector value={draft.mood} onChange={(v) => (draft.mood = v)} />
        </>
      )}

      {step === "energy" && (
        <>
          <Text style={[styles.question, { color: theme.text }]}>What's your energy level?</Text>
          <ScaleSelector value={draft.energy} onChange={(v) => (draft.energy = v)} />
        </>
      )}

      {step === "sleep" && (
        <>
          <Text style={[styles.question, { color: theme.text }]}>How many hours did you sleep?</Text>
          <TextInput
            keyboardType="numeric"
            defaultValue={String(draft.sleep_hours)}
            onChangeText={(t) => (draft.sleep_hours = Number(t) || 0)}
            style={[styles.input, { color: theme.text, borderColor: theme.border }]}
            placeholder="7.5"
            placeholderTextColor={theme.textMuted}
          />
        </>
      )}

      {step === "priorities" && (
        <>
          <Text style={[styles.question, { color: theme.text }]}>Top priority for today?</Text>
          <TextInput
            value={priorityInput}
            onChangeText={setPriorityInput}
            onSubmitEditing={() => {
              if (priorityInput.trim()) {
                draft.top_priorities.push(priorityInput.trim());
                setPriorityInput("");
              }
            }}
            style={[styles.input, { color: theme.text, borderColor: theme.border }]}
            placeholder="e.g. Finish client proposal"
            placeholderTextColor={theme.textMuted}
          />
          {draft.top_priorities.map((p, i) => (
            <Text key={i} style={{ color: theme.textMuted, marginTop: spacing.xs }}>
              • {p}
            </Text>
          ))}
        </>
      )}

      <Pressable onPress={goNext} style={[styles.nextButton, { backgroundColor: theme.primary }]}>
        <Text style={styles.nextText}>
          {currentIndex < STEPS.length - 1 ? "Next" : "Finish check-in"}
        </Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: spacing.lg, paddingTop: spacing.xl * 2, gap: spacing.lg },
  progressRow: { flexDirection: "row", gap: spacing.xs },
  progressDot: { flex: 1, height: 4, borderRadius: radius.full },
  question: { fontSize: 22, fontWeight: "700" },
  scaleRow: { flexDirection: "row", gap: spacing.sm, justifyContent: "space-between" },
  scaleDot: {
    width: 52,
    height: 52,
    borderRadius: radius.full,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  input: { borderWidth: 1, borderRadius: radius.md, padding: spacing.md, fontSize: 16 },
  nextButton: {
    marginTop: "auto",
    borderRadius: radius.full,
    paddingVertical: 16,
    alignItems: "center",
  },
  nextText: { color: "#fff", fontSize: 16, fontWeight: "600" },
});

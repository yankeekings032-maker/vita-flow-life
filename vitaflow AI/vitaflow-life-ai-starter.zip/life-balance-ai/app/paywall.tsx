// app/paywall.tsx — Premium upsell with Stripe + PayPal
import React, { useState } from "react";
import { View, Text, Pressable, StyleSheet, useColorScheme, Linking, ActivityIndicator } from "react-native";
import { useRouter } from "expo-router";
import { supabase } from "../src/lib/supabase";
import { lightTheme, darkTheme, spacing, radius } from "../src/lib/theme";

type Plan = "monthly" | "annual";
type PaymentMethod = "stripe" | "paypal";

const PLANS: Record<Plan, { price: string; period: string; savingsNote?: string }> = {
  monthly: { price: "$9.99", period: "/month" },
  annual: { price: "$59.99", period: "/year", savingsNote: "Save 50% vs monthly" },
};

const FEATURES = [
  "Unlimited AI coaching & daily insights",
  "Personalized meal plans & workout generation",
  "Advanced analytics across every life domain",
  "Wearable sync (Apple Health / Health Connect)",
  "AI voice coach",
];

export default function PaywallScreen() {
  const scheme = useColorScheme();
  const theme = scheme === "dark" ? darkTheme : lightTheme;
  const router = useRouter();
  const [plan, setPlan] = useState<Plan>("annual");
  const [method, setMethod] = useState<PaymentMethod>("stripe");
  const [loading, setLoading] = useState(false);

  async function startCheckout() {
    setLoading(true);
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      if (method === "stripe") {
        // Server creates a Stripe Checkout Session (card, Apple Pay, Google Pay
        // are all offered by Stripe's payment element automatically).
        const { data, error } = await supabase.functions.invoke("stripe-create-checkout", {
          body: { user_id: user.id, plan },
        });
        if (error) throw error;
        if (data?.url) await Linking.openURL(data.url);
      } else {
        // PayPal order flow: create order server-side, redirect to PayPal approval URL,
        // then a return-URL deep link calls paypal-capture-order to finalize.
        const { data, error } = await supabase.functions.invoke("paypal-create-order", {
          body: { user_id: user.id, plan },
        });
        if (error) throw error;
        if (data?.approveUrl) await Linking.openURL(data.approveUrl);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.bg }]}>
      <Pressable onPress={() => router.back()} style={styles.closeButton}>
        <Text style={{ color: theme.textMuted, fontSize: 22 }}>×</Text>
      </Pressable>

      <Text style={[styles.title, { color: theme.text }]}>VitaFlow Premium</Text>
      <Text style={[styles.subtitle, { color: theme.textMuted }]}>
        Unlock the full picture of your life balance.
      </Text>

      <View style={styles.featureList}>
        {FEATURES.map((f) => (
          <View key={f} style={styles.featureRow}>
            <Text style={[styles.checkmark, { color: theme.success }]}>✓</Text>
            <Text style={[styles.featureText, { color: theme.text }]}>{f}</Text>
          </View>
        ))}
      </View>

      {/* Plan selector */}
      <View style={styles.planRow}>
        {(Object.keys(PLANS) as Plan[]).map((p) => (
          <Pressable
            key={p}
            onPress={() => setPlan(p)}
            style={[
              styles.planCard,
              {
                borderColor: plan === p ? theme.primary : theme.border,
                backgroundColor: theme.surface,
              },
            ]}
          >
            {PLANS[p].savingsNote && (
              <Text style={[styles.savingsBadge, { color: theme.success }]}>{PLANS[p].savingsNote}</Text>
            )}
            <Text style={[styles.planPrice, { color: theme.text }]}>{PLANS[p].price}</Text>
            <Text style={[styles.planPeriod, { color: theme.textMuted }]}>{PLANS[p].period}</Text>
          </Pressable>
        ))}
      </View>

      {/* Payment method selector */}
      <Text style={[styles.sectionLabel, { color: theme.textMuted }]}>Pay with</Text>
      <View style={styles.methodRow}>
        <Pressable
          onPress={() => setMethod("stripe")}
          style={[
            styles.methodCard,
            { borderColor: method === "stripe" ? theme.primary : theme.border, backgroundColor: theme.surface },
          ]}
        >
          <Text style={[styles.methodText, { color: theme.text }]}>Card / Apple Pay / Google Pay</Text>
        </Pressable>
        <Pressable
          onPress={() => setMethod("paypal")}
          style={[
            styles.methodCard,
            { borderColor: method === "paypal" ? theme.primary : theme.border, backgroundColor: theme.surface },
          ]}
        >
          <Text style={[styles.methodText, { color: theme.text }]}>PayPal</Text>
        </Pressable>
      </View>

      <Pressable
        onPress={startCheckout}
        disabled={loading}
        style={[styles.ctaButton, { backgroundColor: theme.primary }]}
      >
        {loading ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={styles.ctaText}>Start 7-day free trial</Text>
        )}
      </Pressable>
      <Text style={[styles.disclaimer, { color: theme.textMuted }]}>
        Cancel anytime. You won't be charged until the trial ends.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: spacing.lg, paddingTop: spacing.xl * 2, gap: spacing.md },
  closeButton: { position: "absolute", top: spacing.xl, right: spacing.lg, zIndex: 1 },
  title: { fontSize: 26, fontWeight: "700" },
  subtitle: { fontSize: 15 },
  featureList: { gap: spacing.sm, marginVertical: spacing.md },
  featureRow: { flexDirection: "row", alignItems: "center", gap: spacing.sm },
  checkmark: { fontWeight: "700" },
  featureText: { fontSize: 14, flex: 1 },
  planRow: { flexDirection: "row", gap: spacing.sm },
  planCard: { flex: 1, borderWidth: 2, borderRadius: radius.lg, padding: spacing.md, alignItems: "center", gap: 2 },
  savingsBadge: { fontSize: 11, fontWeight: "700" },
  planPrice: { fontSize: 22, fontWeight: "700" },
  planPeriod: { fontSize: 12 },
  sectionLabel: { fontSize: 12, fontWeight: "600", marginTop: spacing.sm, textTransform: "uppercase" },
  methodRow: { flexDirection: "row", gap: spacing.sm },
  methodCard: { flex: 1, borderWidth: 2, borderRadius: radius.md, padding: spacing.md, alignItems: "center" },
  methodText: { fontSize: 13, fontWeight: "600", textAlign: "center" },
  ctaButton: { marginTop: spacing.md, borderRadius: radius.full, paddingVertical: 16, alignItems: "center" },
  ctaText: { color: "#fff", fontSize: 16, fontWeight: "700" },
  disclaimer: { fontSize: 12, textAlign: "center" },
});

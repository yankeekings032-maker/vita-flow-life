# VitaFlow Life AI — MVP Starter

Read `docs/00-product-blueprint.md` first — it has the full architecture, schema rationale,
roadmap, monetization, and business docs.

## What's runnable here
- `supabase/migrations/0001_init.sql` — full schema + RLS, ready for `supabase db push`
- `supabase/migrations/0002_subscriptions.sql` — payment/subscription tracking (Stripe + PayPal)
- `supabase/functions/generate-daily-insight` — real OpenAI Edge Function (needs `OPENAI_API_KEY` secret)
- `supabase/functions/compute-life-scores` — deterministic scoring engine, no LLM
- `supabase/functions/stripe-create-checkout` + `stripe-webhook` — Stripe subscriptions (card, Apple Pay, Google Pay all surface automatically via Stripe Checkout)
- `supabase/functions/paypal-create-order` + `paypal-capture-order` — PayPal Orders API checkout flow
- `app/(tabs)/index.tsx` + `app/checkin/[step].tsx` — the core loop UI, wired to Supabase
- `app/(tabs)/planner.tsx`, `health.tsx`, `wellness.tsx` — Planner/Pomodoro, Health Dashboard, Mental Wellness screens
- `app/paywall.tsx` — Premium upsell screen with Stripe / PayPal method switcher
- `src/lib/supabase.ts`, `src/lib/theme.ts`, `src/components/ui/ScoreRing.tsx` — foundation
- `landing-page.html` — standalone marketing site (open directly in a browser)
- `pitch-deck/vitaflow-pitch-deck.pptx` — 11-slide investor deck

## Payments setup
**Stripe:** create two recurring Prices (monthly/annual) in the Stripe Dashboard, set
`STRIPE_SECRET_KEY`, `STRIPE_PRICE_MONTHLY`, `STRIPE_PRICE_ANNUAL`, `STRIPE_WEBHOOK_SECRET`
as function secrets, and register the `stripe-webhook` URL in the Dashboard. Apple Pay and
Google Pay need no separate integration — Stripe Checkout surfaces them automatically on
supported devices once your Stripe account has them enabled.

**PayPal:** create a REST app in the PayPal Developer Dashboard, set `PAYPAL_CLIENT_ID`,
`PAYPAL_CLIENT_SECRET`, and `PAYPAL_ENV` (`sandbox` or `live`) as function secrets. The
included flow uses the Orders API (one-time capture per billing period) for MVP simplicity;
move to the Subscriptions API (`v1/billing/subscriptions`) once you want PayPal to handle
recurring billing natively.

## Setup
```bash
npm install
npx supabase init
npx supabase link --project-ref <your-project-ref>
npx supabase db push
npx supabase functions deploy generate-daily-insight
npx supabase functions deploy compute-life-scores
npx supabase secrets set OPENAI_API_KEY=sk-...
```

Add to `app.json`:
```json
{
  "expo": {
    "extra": {
      "supabaseUrl": "https://<project>.supabase.co",
      "supabaseAnonKey": "<anon-key>"
    }
  }
}
```

```bash
npx expo start
```

## What's next
Follow the "MVP Development Roadmap" (section 13) in the blueprint doc, in order — the
core loop screens here are Week 2's deliverable. Everything else (planner, health,
wellness, gamification, paywall) extends the same pattern: a table in the migration,
a `src/features/<name>/` folder, RLS already scoped to `auth.uid()`.

// src/lib/theme.ts
export const lightTheme = {
  bg: "#FAFAF9",
  surface: "#FFFFFF",
  text: "#1C1C1E",
  textMuted: "#6B7280",
  primary: "#5B6EF5",       // calm indigo — coaching/trust
  success: "#34C759",
  warning: "#FF9F0A",
  danger: "#FF3B30",
  border: "#E5E7EB",
  scoreGradient: ["#5B6EF5", "#34C759"] as const,
};

export const darkTheme = {
  bg: "#0E0F13",
  surface: "#1A1B21",
  text: "#F5F5F7",
  textMuted: "#9CA3AF",
  primary: "#8B9BFF",
  success: "#30D158",
  warning: "#FFB340",
  danger: "#FF453A",
  border: "#2C2D33",
  scoreGradient: ["#8B9BFF", "#30D158"] as const,
};

export type Theme = typeof lightTheme;

export const spacing = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32 };
export const radius = { sm: 8, md: 16, lg: 24, full: 999 };

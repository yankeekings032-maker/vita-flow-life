// src/lib/supabase.ts
import "react-native-url-polyfill/auto";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { createClient } from "@supabase/supabase-js";
import Constants from "expo-constants";

const supabaseUrl = Constants.expoConfig?.extra?.supabaseUrl as string;
const supabaseAnonKey = Constants.expoConfig?.extra?.supabaseAnonKey as string;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error(
    "Missing Supabase config. Set extra.supabaseUrl / extra.supabaseAnonKey in app.json"
  );
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

// ---- Typed helpers used across features ----

export interface Checkin {
  id?: string;
  user_id: string;
  mood: number;
  energy: number;
  sleep_hours: number;
  top_priorities: string[];
  notes?: string;
  created_at?: string;
}

export async function submitCheckin(checkin: Omit<Checkin, "user_id">) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("Not authenticated");

  const { data, error } = await supabase
    .from("checkins")
    .insert({ ...checkin, user_id: user.id })
    .select()
    .single();

  if (error) throw error;

  // Fire-and-forget: trigger score recompute + insight generation server-side
  supabase.functions.invoke("compute-life-scores", { body: { user_id: user.id } });
  supabase.functions.invoke("generate-daily-insight", { body: { user_id: user.id } });

  return data;
}

export async function getLatestScore(userId: string) {
  const { data, error } = await supabase
    .from("life_scores")
    .select("*")
    .eq("user_id", userId)
    .order("score_date", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) throw error;
  return data;
}

export async function getLatestInsight(userId: string) {
  const { data, error } = await supabase
    .from("ai_insights")
    .select("*")
    .eq("user_id", userId)
    .eq("dismissed", false)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) throw error;
  return data;
}

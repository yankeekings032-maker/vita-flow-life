// src/components/ui/ScoreRing.tsx
import React, { useEffect } from "react";
import { View, Text, StyleSheet, useColorScheme } from "react-native";
import Svg, { Circle } from "react-native-svg";
import Animated, {
  useSharedValue,
  useAnimatedProps,
  withTiming,
  Easing,
} from "react-native-reanimated";
import { lightTheme, darkTheme } from "../../lib/theme";

const AnimatedCircle = Animated.createAnimatedComponent(Circle);

interface ScoreRingProps {
  score: number | null; // 0-100, null = not enough data yet
  label?: string;
  size?: number;
}

export function ScoreRing({ score, label = "Life Balance", size = 160 }: ScoreRingProps) {
  const scheme = useColorScheme();
  const theme = scheme === "dark" ? darkTheme : lightTheme;

  const strokeWidth = 12;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;

  const progress = useSharedValue(0);

  useEffect(() => {
    progress.value = withTiming(score ?? 0, {
      duration: 900,
      easing: Easing.out(Easing.cubic),
    });
  }, [score]);

  const animatedProps = useAnimatedProps(() => ({
    strokeDashoffset: circumference * (1 - progress.value / 100),
  }));

  return (
    <View style={styles.container}>
      <Svg width={size} height={size}>
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={theme.border}
          strokeWidth={strokeWidth}
          fill="none"
        />
        <AnimatedCircle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={theme.primary}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          fill="none"
          strokeDasharray={circumference}
          animatedProps={animatedProps}
          rotation={-90}
          origin={`${size / 2}, ${size / 2}`}
        />
      </Svg>
      <View style={StyleSheet.absoluteFillObject as any}>
        <View style={styles.centerContent}>
          <Text style={[styles.scoreText, { color: theme.text }]}>
            {score !== null ? Math.round(score) : "—"}
          </Text>
          <Text style={[styles.labelText, { color: theme.textMuted }]}>
            {score !== null ? label : "Check in to unlock"}
          </Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { alignItems: "center", justifyContent: "center" },
  centerContent: { flex: 1, alignItems: "center", justifyContent: "center" },
  scoreText: { fontSize: 40, fontWeight: "700" },
  labelText: { fontSize: 13, marginTop: 4 },
});

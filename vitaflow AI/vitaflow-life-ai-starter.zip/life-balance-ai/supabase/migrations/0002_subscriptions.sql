-- Adds payment/subscription tracking, provider-agnostic (Stripe + PayPal)
create table subscriptions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  provider text not null check (provider in ('stripe','paypal')),
  provider_subscription_id text,       -- Stripe subscription id OR PayPal order/subscription id
  plan text not null check (plan in ('monthly','annual')),
  status text not null default 'trialing' check (status in ('trialing','active','past_due','canceled','expired')),
  current_period_end timestamptz,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index idx_subscriptions_user on subscriptions (user_id);

alter table subscriptions enable row level security;
create policy "owner_all_subscriptions" on subscriptions
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- profiles.subscription_tier stays the fast-read flag; subscriptions is the source of truth / audit log.

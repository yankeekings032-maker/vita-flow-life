-- Life Balance AI — MVP schema
-- Run via: supabase db push

create extension if not exists "uuid-ossp";

-- ========== PROFILES ==========
create table profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  timezone text default 'UTC',
  focus_domains text[] default '{}',           -- e.g. {health, work, mental}
  onboarding_complete boolean default false,
  subscription_tier text default 'free' check (subscription_tier in ('free','premium','premium_plus')),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- ========== CHECK-INS ==========
create table checkins (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  mood smallint check (mood between 1 and 5),
  energy smallint check (energy between 1 and 5),
  sleep_hours numeric(4,1),
  top_priorities jsonb default '[]',
  notes text,
  created_at timestamptz default now(),
  unique (user_id, created_at)
);
create index idx_checkins_user_date on checkins (user_id, created_at desc);

-- ========== AI INSIGHTS ==========
create table ai_insights (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  category text not null,                       -- mood | sleep | productivity | burnout | general
  insight_text text not null,
  recommendation_text text,
  confidence numeric(3,2),
  source_range_start date,
  source_range_end date,
  dismissed boolean default false,
  created_at timestamptz default now()
);
create index idx_insights_user on ai_insights (user_id, created_at desc);

-- ========== LIFE SCORES ==========
create table life_scores (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  score_date date not null,
  overall_score numeric(5,2),
  health_score numeric(5,2),
  work_score numeric(5,2),
  mental_score numeric(5,2),
  finance_score numeric(5,2),        -- null until v2
  relationship_score numeric(5,2),   -- null until v2
  spiritual_score numeric(5,2),      -- null until v2
  created_at timestamptz default now(),
  unique (user_id, score_date)
);

-- ========== PLANNER ==========
create table tasks (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  title text not null,
  priority smallint default 2 check (priority between 1 and 3), -- 1=high
  due_date date,
  estimated_minutes int,
  is_deep_work boolean default false,
  status text default 'pending' check (status in ('pending','in_progress','done','skipped')),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index idx_tasks_user_status on tasks (user_id, status);

create table pomodoro_sessions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  task_id uuid references tasks(id) on delete set null,
  started_at timestamptz not null,
  duration_minutes int not null,
  completed boolean default false
);

-- ========== HEALTH ==========
create table health_logs (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  log_type text not null check (log_type in ('water','sleep','exercise','weight','steps','heart_rate','nutrition')),
  value numeric not null,
  unit text,
  logged_at timestamptz default now(),
  source text default 'manual'          -- manual | healthkit | health_connect
);
create index idx_health_user_type_date on health_logs (user_id, log_type, logged_at desc);

-- ========== MENTAL WELLNESS ==========
create table journal_entries (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  entry_type text default 'gratitude' check (entry_type in ('gratitude','reflection','free','spiritual')),
  content text not null,
  mood_tag smallint check (mood_tag between 1 and 5),
  is_private boolean default true,
  created_at timestamptz default now()
);

create table breathing_sessions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  pattern text default 'box',           -- box | 4-7-8 | custom
  duration_seconds int not null,
  created_at timestamptz default now()
);

-- ========== FINANCE (v2, schema-ready) ==========
create table expenses (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  amount numeric(12,2) not null,
  category text,
  note text,
  spent_at date default current_date
);

create table budgets (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  category text not null,
  monthly_limit numeric(12,2) not null,
  month date not null
);

create table savings_goals (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  goal_name text not null,
  target_amount numeric(12,2) not null,
  current_amount numeric(12,2) default 0,
  target_date date
);

-- ========== RELATIONSHIPS (v2, schema-ready) ==========
create table important_people (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  name text not null,
  relationship text,
  anniversary_date date,
  checkin_frequency_days int default 14
);

create table acts_of_kindness (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  person_id uuid references important_people(id) on delete set null,
  description text,
  logged_at timestamptz default now()
);

-- ========== LEARNING (v2, schema-ready) ==========
create table learning_items (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade not null,
  item_type text check (item_type in ('book','course','skill')),
  title text not null,
  progress_percent smallint default 0,
  status text default 'active' check (status in ('active','completed','paused'))
);

-- ========== GAMIFICATION ==========
create table user_xp (
  user_id uuid primary key references auth.users(id) on delete cascade,
  total_xp int default 0,
  level int default 1,
  current_streak int default 0,
  longest_streak int default 0,
  last_activity_date date
);

create table badges (
  id uuid primary key default uuid_generate_v4(),
  code text unique not null,
  name text not null,
  description text
);

create table user_badges (
  user_id uuid references auth.users(id) on delete cascade not null,
  badge_id uuid references badges(id) on delete cascade not null,
  earned_at timestamptz default now(),
  primary key (user_id, badge_id)
);

-- ========== ROW LEVEL SECURITY ==========
alter table profiles enable row level security;
alter table checkins enable row level security;
alter table ai_insights enable row level security;
alter table life_scores enable row level security;
alter table tasks enable row level security;
alter table pomodoro_sessions enable row level security;
alter table health_logs enable row level security;
alter table journal_entries enable row level security;
alter table breathing_sessions enable row level security;
alter table expenses enable row level security;
alter table budgets enable row level security;
alter table savings_goals enable row level security;
alter table important_people enable row level security;
alter table acts_of_kindness enable row level security;
alter table learning_items enable row level security;
alter table user_xp enable row level security;
alter table user_badges enable row level security;

-- Generic "owner only" policy applied per table
do $$
declare
  t text;
begin
  for t in select unnest(array[
    'profiles','checkins','ai_insights','life_scores','tasks','pomodoro_sessions',
    'health_logs','journal_entries','breathing_sessions','expenses','budgets',
    'savings_goals','important_people','acts_of_kindness','learning_items',
    'user_xp','user_badges'
  ])
  loop
    execute format(
      'create policy "owner_all_%1$s" on %1$s for all using (auth.uid() = user_id) with check (auth.uid() = user_id);',
      t
    );
  end loop;
  -- profiles/user_xp use user_id as the PK column name matching auth.uid() already, policy above works since column is named user_id in both.
end $$;

-- badges table is public read, no user_id column
alter table badges enable row level security;
create policy "badges_public_read" on badges for select using (true);

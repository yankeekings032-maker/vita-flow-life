// supabase/functions/compute-life-scores/index.ts
// Deterministic scoring engine — NOT an LLM call. Run nightly via cron per user
// (Supabase Scheduled Functions) or on-demand after a check-in.

import { serve } from "https://deno.land/std@0.203.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

const WATER_GOAL_ML = 2000;
const STEPS_GOAL = 8000;
const SLEEP_TARGET_HOURS = 7.5;

function clamp(n: number, min = 0, max = 100) {
  return Math.max(min, Math.min(max, n));
}

async function computeHealthScore(userId: string, since: string) {
  const { data: logs } = await supabase
    .from("health_logs")
    .select("log_type, value, logged_at")
    .eq("user_id", userId)
    .gte("logged_at", since);

  if (!logs || logs.length === 0) return null;

  const byDay: Record<string, Record<string, number>> = {};
  for (const l of logs) {
    const day = l.logged_at.slice(0, 10);
    byDay[day] = byDay[day] || {};
    byDay[day][l.log_type] = (byDay[day][l.log_type] || 0) + Number(l.value);
  }
  const days = Object.values(byDay);
  const n = days.length || 1;

  const waterHitRate =
    days.filter((d) => (d.water || 0) >= WATER_GOAL_ML).length / n;
  const stepsHitRate =
    days.filter((d) => (d.steps || 0) >= STEPS_GOAL).length / n;
  const exerciseFreq =
    days.filter((d) => (d.exercise || 0) > 0).length / n;
  const sleepConsistency =
    1 -
    Math.min(
      1,
      days.reduce(
        (acc, d) => acc + Math.abs((d.sleep || SLEEP_TARGET_HOURS) - SLEEP_TARGET_HOURS),
        0
      ) /
        (n * SLEEP_TARGET_HOURS)
    );

  const score =
    0.3 * sleepConsistency * 100 +
    0.3 * waterHitRate * 100 +
    0.2 * exerciseFreq * 100 +
    0.2 * stepsHitRate * 100;

  return clamp(score);
}

async function computeMentalScore(userId: string, since: string) {
  const { data: checkins } = await supabase
    .from("checkins")
    .select("mood, energy")
    .eq("user_id", userId)
    .gte("created_at", since);

  const { data: journals } = await supabase
    .from("journal_entries")
    .select("id")
    .eq("user_id", userId)
    .gte("created_at", since);

  if (!checkins || checkins.length === 0) return null;

  const avgMood =
    checkins.reduce((a, c) => a + (c.mood || 0), 0) / checkins.length;
  const avgEnergy =
    checkins.reduce((a, c) => a + (c.energy || 0), 0) / checkins.length;
  const journalFreqBonus = Math.min(20, (journals?.length ?? 0) * 2);

  // mood/energy are 1-5 scales -> normalize to 0-80, journaling adds up to 20
  const score = ((avgMood + avgEnergy) / 10) * 80 + journalFreqBonus;
  return clamp(score);
}

async function computeWorkScore(userId: string, since: string) {
  const { data: tasks } = await supabase
    .from("tasks")
    .select("status, is_deep_work")
    .eq("user_id", userId)
    .gte("created_at", since);

  if (!tasks || tasks.length === 0) return null;

  const completionRate =
    tasks.filter((t) => t.status === "done").length / tasks.length;
  const deepWorkRate =
    tasks.filter((t) => t.is_deep_work && t.status === "done").length /
    Math.max(1, tasks.filter((t) => t.is_deep_work).length);

  const score = 0.7 * completionRate * 100 + 0.3 * deepWorkRate * 100;
  return clamp(score);
}

serve(async (req) => {
  try {
    const { user_id } = await req.json();
    if (!user_id) {
      return new Response(JSON.stringify({ error: "user_id required" }), {
        status: 400,
      });
    }

    const since = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();

    const [health, mental, work] = await Promise.all([
      computeHealthScore(user_id, since),
      computeMentalScore(user_id, since),
      computeWorkScore(user_id, since),
    ]);

    const activeScores = [health, mental, work].filter(
      (s): s is number => s !== null
    );
    const overall =
      activeScores.length > 0
        ? clamp(activeScores.reduce((a, b) => a + b, 0) / activeScores.length)
        : null;

    const { data, error } = await supabase
      .from("life_scores")
      .upsert(
        {
          user_id,
          score_date: new Date().toISOString().slice(0, 10),
          overall_score: overall,
          health_score: health,
          work_score: work,
          mental_score: mental,
        },
        { onConflict: "user_id,score_date" }
      )
      .select()
      .single();

    if (error) throw error;

    return new Response(JSON.stringify({ scores: data }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
    });
  }
});

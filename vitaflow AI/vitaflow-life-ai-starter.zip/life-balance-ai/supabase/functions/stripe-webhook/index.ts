// supabase/functions/stripe-webhook/index.ts
// Handles Stripe subscription lifecycle events and keeps profiles.subscription_tier
// + subscriptions table in sync. Register this URL in the Stripe Dashboard.
//
// Secrets needed: STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY

import { serve } from "https://deno.land/std@0.203.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@16?target=deno";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY")!, {
  apiVersion: "2024-06-20",
});
const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET")!;

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

async function setTier(userId: string, tier: "free" | "premium") {
  await supabase.from("profiles").update({ subscription_tier: tier }).eq("user_id", userId);
}

serve(async (req) => {
  const signature = req.headers.get("stripe-signature");
  const body = await req.text();

  let event: Stripe.Event;
  try {
    event = await stripe.webhooks.constructEventAsync(body, signature!, webhookSecret);
  } catch (err) {
    return new Response(`Webhook signature verification failed: ${err}`, { status: 400 });
  }

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        const userId = session.client_reference_id;
        if (userId) {
          await supabase
            .from("subscriptions")
            .update({
              status: "active",
              provider_subscription_id: session.subscription as string,
              updated_at: new Date().toISOString(),
            })
            .eq("user_id", userId)
            .eq("provider", "stripe");
          await setTier(userId, "premium");
        }
        break;
      }
      case "customer.subscription.updated": {
        const sub = event.data.object as Stripe.Subscription;
        const { data: row } = await supabase
          .from("subscriptions")
          .select("user_id")
          .eq("provider_subscription_id", sub.id)
          .maybeSingle();
        if (row) {
          const active = sub.status === "active" || sub.status === "trialing";
          await supabase
            .from("subscriptions")
            .update({
              status: sub.status,
              current_period_end: new Date(sub.current_period_end * 1000).toISOString(),
              updated_at: new Date().toISOString(),
            })
            .eq("provider_subscription_id", sub.id);
          await setTier(row.user_id, active ? "premium" : "free");
        }
        break;
      }
      case "customer.subscription.deleted": {
        const sub = event.data.object as Stripe.Subscription;
        const { data: row } = await supabase
          .from("subscriptions")
          .select("user_id")
          .eq("provider_subscription_id", sub.id)
          .maybeSingle();
        if (row) {
          await supabase
            .from("subscriptions")
            .update({ status: "canceled", updated_at: new Date().toISOString() })
            .eq("provider_subscription_id", sub.id);
          await setTier(row.user_id, "free");
        }
        break;
      }
      default:
        break; // ignore other event types
    }

    return new Response(JSON.stringify({ received: true }), { status: 200 });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), { status: 500 });
  }
});

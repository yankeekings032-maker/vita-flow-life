// supabase/functions/paypal-create-order/index.ts
// Creates a PayPal order for the selected plan. PayPal's REST Orders API is used
// here (v2/checkout/orders) rather than Subscriptions API for MVP simplicity —
// renewals are handled by re-prompting checkout near period end, or upgrade to
// PayPal Subscriptions API (v1/billing/subscriptions) once volume justifies it.
//
// Secrets needed: PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET, PAYPAL_ENV (sandbox|live),
// SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, APP_RETURN_URL

import { serve } from "https://deno.land/std@0.203.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

const PAYPAL_BASE =
  Deno.env.get("PAYPAL_ENV") === "live"
    ? "https://api-m.paypal.com"
    : "https://api-m.sandbox.paypal.com";

const PLAN_AMOUNTS: Record<string, string> = {
  monthly: "9.99",
  annual: "59.99",
};

async function getAccessToken() {
  const clientId = Deno.env.get("PAYPAL_CLIENT_ID")!;
  const secret = Deno.env.get("PAYPAL_CLIENT_SECRET")!;
  const res = await fetch(`${PAYPAL_BASE}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${btoa(`${clientId}:${secret}`)}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials",
  });
  const data = await res.json();
  return data.access_token as string;
}

serve(async (req) => {
  try {
    const { user_id, plan } = await req.json();
    if (!user_id || !PLAN_AMOUNTS[plan]) {
      return new Response(JSON.stringify({ error: "user_id and valid plan required" }), {
        status: 400,
      });
    }

    const accessToken = await getAccessToken();

    const orderRes = await fetch(`${PAYPAL_BASE}/v2/checkout/orders`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        intent: "CAPTURE",
        purchase_units: [
          {
            reference_id: user_id,
            description: `VitaFlow Life AI — ${plan} plan`,
            amount: { currency_code: "USD", value: PLAN_AMOUNTS[plan] },
          },
        ],
        application_context: {
          brand_name: "VitaFlow Life AI",
          return_url: `${Deno.env.get("APP_RETURN_URL")}/paywall/paypal-return`,
          cancel_url: `${Deno.env.get("APP_RETURN_URL")}/paywall`,
          user_action: "PAY_NOW",
        },
      }),
    });

    const order = await orderRes.json();
    const approveUrl = order.links?.find((l: { rel: string }) => l.rel === "approve")?.href;

    await supabase.from("subscriptions").insert({
      user_id,
      provider: "paypal",
      provider_subscription_id: order.id,
      plan,
      status: "trialing",
    });

    return new Response(JSON.stringify({ orderId: order.id, approveUrl }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), { status: 500 });
  }
});

// supabase/functions/paypal-capture-order/index.ts
// Called from the app's deep-link return handler after the user approves
// payment in PayPal. Captures the order and unlocks Premium.
//
// Secrets needed: PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET, PAYPAL_ENV,
// SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY

import { serve } from "https://deno.land/std@0.203.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

const PAYPAL_BASE =
  Deno.env.get("PAYPAL_ENV") === "live"
    ? "https://api-m.paypal.com"
    : "https://api-m.sandbox.paypal.com";

async function getAccessToken() {
  const clientId = Deno.env.get("PAYPAL_CLIENT_ID")!;
  const secret = Deno.env.get("PAYPAL_CLIENT_SECRET")!;
  const res = await fetch(`${PAYPAL_BASE}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${btoa(`${clientId}:${secret}`)}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials",
  });
  const data = await res.json();
  return data.access_token as string;
}

serve(async (req) => {
  try {
    const { order_id } = await req.json();
    if (!order_id) {
      return new Response(JSON.stringify({ error: "order_id required" }), { status: 400 });
    }

    const accessToken = await getAccessToken();
    const captureRes = await fetch(
      `${PAYPAL_BASE}/v2/checkout/orders/${order_id}/capture`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );
    const capture = await captureRes.json();
    const success = capture.status === "COMPLETED";

    const { data: subRow } = await supabase
      .from("subscriptions")
      .select("user_id, plan")
      .eq("provider_subscription_id", order_id)
      .eq("provider", "paypal")
      .maybeSingle();

    if (subRow) {
      const periodDays = subRow.plan === "annual" ? 365 : 30;
      await supabase
        .from("subscriptions")
        .update({
          status: success ? "active" : "past_due",
          current_period_end: new Date(Date.now() + periodDays * 86400000).toISOString(),
          updated_at: new Date().toISOString(),
        })
        .eq("provider_subscription_id", order_id);

      if (success) {
        await supabase
          .from("profiles")
          .update({ subscription_tier: "premium" })
          .eq("user_id", subRow.user_id);
      }
    }

    return new Response(JSON.stringify({ success, capture }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), { status: 500 });
  }
});

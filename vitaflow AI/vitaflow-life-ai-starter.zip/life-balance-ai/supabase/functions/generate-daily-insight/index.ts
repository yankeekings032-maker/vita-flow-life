// supabase/functions/generate-daily-insight/index.ts
// Deno Edge Function — computes pattern stats in SQL, then asks the LLM to phrase them.
// Deploy: supabase functions deploy generate-daily-insight
// Secrets needed: OPENAI_API_KEY, SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY

import { serve } from "https://deno.land/std@0.203.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

interface CheckinRow {
  mood: number;
  energy: number;
  sleep_hours: number;
  created_at: string;
}

function dayOfWeek(iso: string) {
  return new Date(iso).toLocaleDateString("en-US", { weekday: "long" });
}

// Deterministic stats — the LLM narrates these, it never invents numbers.
function computeStats(checkins: CheckinRow[]) {
  const byDow: Record<string, number[]> = {};
  for (const c of checkins) {
    const dow = dayOfWeek(c.created_at);
    byDow[dow] = byDow[dow] || [];
    byDow[dow].push(c.mood);
  }
  const dowAverages = Object.entries(byDow).map(([dow, moods]) => ({
    dow,
    avgMood: moods.reduce((a, b) => a + b, 0) / moods.length,
    n: moods.length,
  }));

  const avgSleep =
    checkins.reduce((a, c) => a + (c.sleep_hours || 0), 0) /
    (checkins.length || 1);

  const sleepMoodPairs = checkins
    .filter((c) => c.sleep_hours != null && c.mood != null)
    .map((c) => ({ sleep: c.sleep_hours, mood: c.mood }));

  return { dowAverages, avgSleep, sleepMoodPairs, n: checkins.length };
}

async function callOpenAI(stats: unknown) {
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${Deno.env.get("OPENAI_API_KEY")}`,
    },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      response_format: { type: "json_object" },
      messages: [
        {
          role: "system",
          content:
            "You are a supportive, concise life-balance coach. You are given " +
            "PRE-COMPUTED statistics about a user's mood/sleep/energy check-ins. " +
            "Never invent numbers not present in the input. Never give clinical, " +
            "medical, or financial advice. If the data suggests self-harm risk, " +
            "output category='crisis' and insight_text='' — the app will show a " +
            "static crisis resource instead of your text. " +
            "Return strict JSON: {\"insight_text\": string, \"recommendation_text\": string, " +
            "\"category\": \"mood\"|\"sleep\"|\"productivity\"|\"burnout\"|\"general\"|\"crisis\", " +
            "\"confidence\": number between 0 and 1}. " +
            "insight_text should be one plain-language sentence, e.g. " +
            "'Your mood tends to dip on Tuesdays' — only say this if the stats support it.",
        },
        {
          role: "user",
          content: `Stats for the last 14 days: ${JSON.stringify(stats)}`,
        },
      ],
      max_tokens: 300,
    }),
  });
  const data = await res.json();
  const content = data.choices?.[0]?.message?.content ?? "{}";
  return JSON.parse(content);
}

serve(async (req) => {
  try {
    const { user_id } = await req.json();
    if (!user_id) {
      return new Response(JSON.stringify({ error: "user_id required" }), {
        status: 400,
      });
    }

    const fourteenDaysAgo = new Date(
      Date.now() - 14 * 24 * 60 * 60 * 1000
    ).toISOString();

    const { data: checkins, error } = await supabase
      .from("checkins")
      .select("mood, energy, sleep_hours, created_at")
      .eq("user_id", user_id)
      .gte("created_at", fourteenDaysAgo)
      .order("created_at", { ascending: true });

    if (error) throw error;
    if (!checkins || checkins.length < 3) {
      return new Response(
        JSON.stringify({ skipped: true, reason: "not enough data yet" }),
        { status: 200 }
      );
    }

    const stats = computeStats(checkins as CheckinRow[]);
    const aiResult = await callOpenAI(stats);

    if (aiResult.category === "crisis") {
      // Do not store or surface generated text for crisis signals.
      // App-side should render a static, non-AI crisis resource card instead.
      return new Response(JSON.stringify({ crisis: true }), { status: 200 });
    }

    const { data: inserted, error: insertError } = await supabase
      .from("ai_insights")
      .insert({
        user_id,
        category: aiResult.category ?? "general",
        insight_text: aiResult.insight_text,
        recommendation_text: aiResult.recommendation_text,
        confidence: aiResult.confidence ?? 0.5,
        source_range_start: fourteenDaysAgo.slice(0, 10),
        source_range_end: new Date().toISOString().slice(0, 10),
      })
      .select()
      .single();

    if (insertError) throw insertError;

    return new Response(JSON.stringify({ insight: inserted }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
    });
  }
});

// supabase/functions/stripe-create-checkout/index.ts
// Creates a Stripe Checkout Session. Stripe's hosted Checkout automatically
// offers card, Apple Pay, and Google Pay based on the buyer's device — no
// separate integration needed for those two.
//
// Secrets needed: STRIPE_SECRET_KEY, STRIPE_PRICE_MONTHLY, STRIPE_PRICE_ANNUAL,
// SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, APP_RETURN_URL (deep link scheme)

import { serve } from "https://deno.land/std@0.203.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@16?target=deno";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY")!, {
  apiVersion: "2024-06-20",
});

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

const PRICE_IDS: Record<string, string> = {
  monthly: Deno.env.get("STRIPE_PRICE_MONTHLY")!,
  annual: Deno.env.get("STRIPE_PRICE_ANNUAL")!,
};

serve(async (req) => {
  try {
    const { user_id, plan } = await req.json();
    if (!user_id || !PRICE_IDS[plan]) {
      return new Response(JSON.stringify({ error: "user_id and valid plan required" }), {
        status: 400,
      });
    }

    const { data: profile } = await supabase
      .from("profiles")
      .select("display_name")
      .eq("user_id", user_id)
      .maybeSingle();

    const { data: authUser } = await supabase.auth.admin.getUserById(user_id);
    const email = authUser?.user?.email;

    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      line_items: [{ price: PRICE_IDS[plan], quantity: 1 }],
      subscription_data: { trial_period_days: 7 },
      customer_email: email ?? undefined,
      client_reference_id: user_id,
      success_url: `${Deno.env.get("APP_RETURN_URL")}/paywall/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${Deno.env.get("APP_RETURN_URL")}/paywall`,
      // Apple Pay / Google Pay surface automatically in Checkout's payment element
      // when the buyer's device/browser supports them — no extra config required.
      allow_promotion_codes: true,
    });

    await supabase.from("subscriptions").insert({
      user_id,
      provider: "stripe",
      provider_subscription_id: session.id,
      plan,
      status: "trialing",
    });

    return new Response(JSON.stringify({ url: session.url }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), { status: 500 });
  }
});
